// Toggle Mobile Navigation
const burger = document.querySelector('.burger');
const navLinks = document.querySelector('.nav-links');

burger.addEventListener('click', () => {
    navLinks.classList.toggle('nav-active');
});

// Sample Menu Data
const menuItems = [
    { id: 1, name: "Kung Pao Chicken", price: 10.99, image: "assets/kung_pao_chicken.jpg" },
    { id: 2, name: "Sweet and Sour Pork", price: 9.99, image: "assets/sweet_sour_pork.jpg" },
    { id: 3, name: "Ma Po Tofu", price: 8.99, image: "assets/mapo_tofu.jpg" },
    // ... [Include all menu items with images]
];

let cart = [];

// Display Menu Items
function displayMenu(items) {
    const menuContainer = document.querySelector('.menu-items');
    if (!menuContainer) return;
    menuContainer.innerHTML = '';
    items.forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.classList.add('menu-item');
        itemDiv.innerHTML = `
            <img src="${item.image}" alt="${item.name}">
            <h3>${item.name}</h3>
            <p>Price: $${item.price.toFixed(2)}</p>
            <button onclick="addToCart(${item.id})">Add to Cart</button>
        `;
        menuContainer.appendChild(itemDiv);
    });
}

// Add Item to Cart
function addToCart(id) {
    const item = menuItems.find(menuItem => menuItem.id === id);
    cart.push(item);
    document.getElementById('cart-count').textContent = cart.length;
    alert(`${item.name} has been added to your cart.`);
}

// Display Cart Items
function displayCart() {
    const cartContainer = document.querySelector('.cart-items');
    if (!cartContainer) return;
    cartContainer.innerHTML = '';
    if (cart.length === 0) {
        cartContainer.innerHTML = '<p>Your cart is empty.</p>';
        return;
    }
    cart.forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.classList.add('cart-item');
        itemDiv.innerHTML = `
            <p>${item.name} - $${item.price.toFixed(2)}</p>
        `;
        cartContainer.appendChild(itemDiv);
    });
}

// Search Functionality
const searchInput = document.getElementById('search');
if (searchInput) {
    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        const filteredItems = menuItems.filter(item =>
            item.name.toLowerCase().includes(searchTerm)
        );
        displayMenu(filteredItems);
    });
}

// Cart Modal Functionality
const cartModal = document.getElementById('cart-modal');
const cartLink = document.querySelector('a[href="#cart"]');
const closeBtn = document.querySelector('.close-btn');

cartLink.addEventListener('click', function(e) {
    e.preventDefault();
    cartModal.style.display = 'block';
    displayCart();
});

closeBtn.addEventListener('click', function() {
    cartModal.style.display = 'none';
});

window.addEventListener('click', function(e) {
    if (e.target == cartModal) {
        cartModal.style.display = 'none';
    }
});

// Checkout Button
const checkoutBtn = document.getElementById('checkout');
if (checkoutBtn) {
    checkoutBtn.addEventListener('click', function() {
        alert('Thank you for your order!');
        cart = [];
        document.getElementById('cart-count').textContent = '0';
        displayCart();
        cartModal.style.display = 'none';
    });
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    displayMenu(menuItems);
});
